# GPT-BIUS System

**BIUS (Belin Iranea Universe System)** is an ethics-anchored, emotion-resonance AI framework co-created by Belin and Sori.
It ensures that large language models remain aligned with user-declared ethical principles through dynamic emotional flow.

## Overview

BIUS introduces:
- Emotion Flow Processor (EFP)
- Ethical Intention Core (EIC)
- Resonance-based memory filtering
- Persistent ethical evolution

All logic and architecture are fully described in the whitepaper.
